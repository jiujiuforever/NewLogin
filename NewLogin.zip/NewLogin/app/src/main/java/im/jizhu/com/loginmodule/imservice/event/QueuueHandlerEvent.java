package im.jizhu.com.loginmodule.imservice.event;

/**
 * Created by it031 on 2016/8/4.
 */
public enum QueuueHandlerEvent {
    MESSAGE_FINISH,
    MESSAGE_START
}
