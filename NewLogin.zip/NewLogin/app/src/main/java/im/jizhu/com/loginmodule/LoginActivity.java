package im.jizhu.com.loginmodule;

import android.content.Context;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;

import im.jizhu.com.loginmodule.DB.sp.LoginSp;
import im.jizhu.com.loginmodule.DB.sp.SystemConfigSp;
import im.jizhu.com.loginmodule.imservice.manager.IMSocketManager;

public class LoginActivity extends AppCompatActivity {

    //所有的管理类
    private IMSocketManager socketMgr = IMSocketManager.instance();
    private LoginSp loginSp = LoginSp.instance();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.mian_login);
        //应用开启初始化 下面这几个怎么释放 todo
        Context ctx = getApplicationContext();
        SystemConfigSp.instance().init(ctx);
        loginSp.init(ctx);
        // 放在这里还有些问题 todo
        socketMgr.onStartIMManager(ctx);
        socketMgr.reqMsgServerAddrs();
    }
}
