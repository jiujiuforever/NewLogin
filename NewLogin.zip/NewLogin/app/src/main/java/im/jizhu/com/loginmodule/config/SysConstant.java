package im.jizhu.com.loginmodule.config;

/**
 * Created by it031 on 2017/12/5.
 */

public class SysConstant {
    /**协议头相关 start*/
    public static final int PROTOCOL_HEADER_LENGTH = 16;// 默认消息头的长度
    public static final int PROTOCOL_VERSION = 6;
    public static final int PROTOCOL_FLAG = 0;
    public static final char PROTOCOL_ERROR = '0';
    public static final char PROTOCOL_RESERVED = '0';
}
