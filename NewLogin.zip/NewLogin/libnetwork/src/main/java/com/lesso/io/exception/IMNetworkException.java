package com.lesso.io.exception;

/**
 * 网络异常
 * Created by zhengxiaoming on 2017/7/17.
 */
public class IMNetworkException extends RuntimeException{

    public IMNetworkException(String message) {
        super(message);
    }
}
